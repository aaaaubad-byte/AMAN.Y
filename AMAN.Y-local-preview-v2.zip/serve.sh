#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
PORT="${PORT:-8000}"
printf 'AMAN local reference: http://127.0.0.1:%s/\n' "$PORT"
exec python3 -m http.server "$PORT" --bind 127.0.0.1
